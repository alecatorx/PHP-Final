<?php
  // Step 1: (2 points) Include your connection
  // CREATE YOUR CONNECTION BELOW THIS LINE

  require("_connect.php");
  $conn = dbo();

  // Step 2: (20 points) Delete the existing 'supers' row from the database
  // CREATE YOUR QUERY LOGIC BELOW THIS LINE

  $sql = "DELETE FROM supers WHERE id = {$_GET['id']}";

  $stmt = dbo()->prepare($sql);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // Step 3: (16 points) Perform basic error handling and redirect the user with a success or error message
  // Ensure you store the messages into the $_SESSION
  // Ensure you exit after your redirect
  // CREATE YOUR ERROR HANDLING BELOW THIS LINE

  function error_handler ($errors) {
    if (count($errors) > 0) {
      if (session_status() === PHP_SESSION_NONE) session_start();

      $_SESSION['form_values'] = $_POST;
      $_SESSION['errors'] = $errors;

      header('Location: index.php');
      die(); //uh oh edgelord coming through
    }
  }
      // array to hold all the field errors
      $errors = [];

  error_handler($errors);

  try {
    $stmt->execute();

    session_start();
    $_SESSION['successes'][] = "You have successfully deleted the super.";
    header('Location: index.php');
    exit;
  } catch (PDOException $error) {
  if ($stmt->errorCode() === "23000")
    $errors[] = "You have already deleted this super!";
  else if ($stmt->errorCode() !== "00000")
    $errors[] = "There was an error deleting the super.";
    error_handler($errors);
  }
  
  // TOTAL POINTS POSSIBLE: 38
?>