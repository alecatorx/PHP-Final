<?php
  // Step 1: (2 points) Include your connection
  // CREATE YOUR CONNECTION BELOW THIS LINE

  require("_connect.php");
  $conn = dbo();

  // Step 2: (20 points) Update the existing 'supers' row in the database
  // CREATE YOUR QUERY LOGIC BELOW THIS LINE

  $sql = "UPDATE supers SET
    first_name = '{$_POST['first_name']}',
    last_name = '{$_POST['last_name']}',
    date_of_birth = '{$_POST['DOB']}',
    alias = '{$_POST['alias']}',
    active = '{$_POST['active']}'
  WHERE id = '{$_POST['id']}'";

$stmt = dbo()->prepare($sql);
$stmt->bindParam(':id', $_GET["id"], PDO::PARAM_INT);
$stmt->execute();

  // Step 3: (16 points) Perform basic error handling and redirect the user with a success or error message
  // Ensure you store the messages into the $_SESSION
  // Ensure you exit after your redirect
  // CREATE YOUR ERROR HANDLING BELOW THIS LINE

  function error_handler ($errors) {
    if (count($errors) > 0) {
      if (session_status() === PHP_SESSION_NONE) session_start();
  
      $_SESSION['form_values'] = $_POST;
      $_SESSION['errors'] = $errors;
  
      header('Location: new.php');
      die();
    }
  }

  error_handler($errors);

  try {
    $stmt->execute();

    session_start();
    $_SESSION['successes'][] = "You have successfully updated the super.";
    header('Location: index.php');
    die;
  } catch (PDOException $error) {
  if ($stmt->errorCode() === "23000")
    $errors[] = "You have already updated this super!";
  else if ($stmt->errorCode() !== "00000")
    $errors[] = "There was an error updating this super.";
    error_handler($errors);
  }

  // TOTAL POINTS POSSIBLE: 38
?>