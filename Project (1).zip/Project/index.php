<?php
  // Step 1: (2 points) Include your connection
  // CREATE YOUR CONNECTION BELOW THIS LINE

  require("_connect.php");
  $conn = dbo();

  // Step 2: (5 points) Retrieve all the 'supers' rows from your database
  // CREATE YOUR QUERY LOGIC BELOW THIS LINE

  if (session_status() === PHP_SESSION_NONE) session_start();

  $sql = "SELECT * FROM supers";
  $stmt = dbo()->prepare($sql);
  $stmt->bindPram(':id', $user['id'], PDO::PARAM_INT);
  $stmt->execute();
  $supers = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!-- Step 3: (2 points) Include your header here -->

<?php include_once('_header.php')?>

<!-- Step 4: (2 points) Create a navigation bar for home.php and new.php -->
<!-- CREATE YOUR NAVIGATION HTML BELOW THIS LINE -->

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">PHP Final Project</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" 
    data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" 
    aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="<?= BASE_PATH ?>">Home<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= BASE_PATH ?>/new">New</a>
      </li>
    </ul>
  </div>
</nav>

<!-- Step 5: (15 points) Create a table that display each row from the database -->
<!-- You only need to display the first_name, last_name, date_of_birth, -->
<!-- alias, active, and hero columns -->

<!-- Step 6: (6 points) Create action links pointing to 'edit.php' and 'delete.php' -->
<!-- Ensure there was one edit and delete link for each row -->

<!-- CREATE YOUR TABLE BELOW THIS LINE -->

<table class="table table-striped my-7">
  <thead>
    <tr>
      <td>First Name</td>
      <td>last Name</td>
      <td>Date Of Birth</td>
      <td>Alias</td>
      <td>Active</td>
      <td>Hero</td>
      <td>Actions</td>
    </tr>
  </thead>

  <tbody>
    <?php foreach($supers as $super): ?>
      <tr>
        <td><?= $super["first_name"] ?></td>
        <td><?= $super["last_name"] ?></td>
        <td><?= $super["date_of_birth"] ?></td>
        <td><?= $super["alias"] ?></td>
        <td><?= $super["active"] ?></td>
        <td><?= $super["hero"] ?></td>
        <td>
          <a href="edit.php?id=<?=$super["id"] ?>">Edit</a>
          |
          <a href="delete.php?id=<?= $super["id"] ?>" onClick=
            "return confirm('Are you sure you want to delete?')">Delete</a>
        </td>
      </tr>
    <?php endforeach ?>
  </tbody>
</table>

<!-- Step 7: (2 points) Include your footer here -->

<?php include_once('_footer.php') ?>

<!-- TOTAL POINTS POSSIBLE: 34 -->