<?php

  // Step 1: (12) Using either MySQLi or PDO
  //    Create a connection to your MySQL DB and store it in a variable named $conn
  // CREATE YOUR CONNECTION BELOW THE LINE

  function dbo(){
    try {
      $dsn = 'mysql:host=localhost;dbname=project01';
      $username = 'root'; 
      $password = '';

      $conn = new PDO($dsn,$username, $password); 

      //report SQL errors
      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      return $conn;
    } catch (PDOException $error){
      //start the session if there isn't currently one
      if (session_status() === PHP_SESSION_NONE) session_start();
      $_SESSION['errors'][] = $error->getMessage();
    }
  }

  // TOTAL POINTS POSSIBLE: 6

?>