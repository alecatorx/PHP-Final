<!-- Step 1: (5 points) Put your basic opening HTML here -->
<!-- and any logic you require for including style sheets -->
<!-- Ensure you only have from opening <html> to opening <body> here -->
<!-- and not the closing </body> or closing </html> tags -->
<!-- Ensure you HTML is W3C compliant -->
<!-- CREATE YOUR HEADER HTML BELOW THIS LINE -->
<?php 

    require_once("_connect.php"); 

    $dir = dirname(__FILE__) . '\_includes';
    set_include_path($dir);

    $document_root = realpath($_SERVER["DOCUMENT_ROOT"]);
    $application_root = dirname(__FILE__);
    $link_path = str_replace($document_root, '', $application_root);
    define('BASE_PATH', $link_path);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= BASE_PATH ?>/css/styles.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
         rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" 
         crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" 
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" 
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" 
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" 
        crossorigin="anonymous"></script><title>Final Project</title>
</head>
<body>
<?php include_once('notification.php'); ?>


<!-- TOTAL POINTS POSSIBLE: 5 -->