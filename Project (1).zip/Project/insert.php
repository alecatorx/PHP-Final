<?php 
  // Step 1: (2 points) Include your connection
  // CREATE YOUR CONNECTION BELOW THIS LINE

  require("_connect.php");
  $conn = dbo();

  // Step 2: (17 points) Insert the new 'supers' row into the database
  // CREATE YOUR QUERY LOGIC BELOW THIS LINE
  $first_name = filter_input(INPUT_POST, 'first_name', FILTER_SANITIZE_STRING);
  $last_name = filter_input(INPUT_POST, 'last_name', FILTER_SANITIZE_STRING);
  $date_of_birth = filter_input(INPUT_POST, 'date_of_birth', FILTER_SANITIZE_STRING);
  $alias = filter_input(INPUT_POST, 'alias', FILTER_SANITIZE_STRING);
  $active = filter_input(INPUT_POST, 'active', FILTER_SANITIZE_STRING);

  // Validate the necessary fields are not empty
  $required_fields = [
    'first_name',
    'last_name',
    'date_of_birth',
    'alias',
    'active'
  ];
  foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
      $human_field = str_replace("_", " ", $field);
      $errors[] = "You cannot leave the {$human_field} blank."; //sounds like an alien
    }
  }

    // Normalize the string fields
    foreach (['first_name', 'last_name','date_of_birth', 'alias', 'active'] as $field) {
      $$field = strtolower($$field);
      $$field = ucwords($$field);
    }

  $sql = "INSERT INTO supers (
    first_name,
    last_name,
    date_of_birth,
    alias,
    active
  ) VALUES (
    :first_name,
    :last_name,
    :date_of_birth,
    :alias,
    :active
  )";

  //prepare the sql and bind the values
  $stmt = $conn->prepare($sql);
  $stmt->bindParam(':first_name', $first_name, PDO::PARAM_STR);
  $stmt->bindParam(':last_name', $last_name, PDO::PARAM_STR);
  $stmt->bindParam(':date_of_birth', $date_of_birth, PDO::PARAM_STR);
  $stmt->bindParam(':alias', $alias, PDO::PARAM_STR);
  $stmt->bindParam(':active', $active, PDO::PARAM_STR);

  // Step 3: (16 points) Perform basic error handling and redirect the user with a success or error message
  // Ensure you store the messages into the $_SESSION
  // Ensure you exit after your redirect
  // CREATE YOUR ERROR HANDLING BELOW THIS LINE
  
  error_handler($errors);

  // Insert the row
  try {
    $stmt->execute();

    session_start();
    $_SESSION['successes'][] = "You have successfully created the super.";
    header('Location: index.php');
    die;

  } catch (PDOException $error) {
  if ($stmt->errorCode() === "23000")
    $errors[] = "You have already created this super!";
  else if ($stmt->errorCode() !== "00000")
    $errors[] = "There was an error creating this super.";
    error_handler($errors);
  }


  // TOTAL POINTS POSSIBLE: 35
?>