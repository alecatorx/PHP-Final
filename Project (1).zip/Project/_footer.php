<!-- Step 1: (5 points) Put your basic closing HTML here -->
<!-- Ensure you only have from closing </html> to closing </body> here -->
<!-- and not the opening <body> or opening <html> tags -->
<!-- Ensure you HTML is W3C compliant -->
<!-- CREATE YOUR FOOTER HTML BELOW THIS LINE -->


    </body>
</html>

<!-- TOTAL POINTS POSSIBLE: 5 -->